# GeM BidSure AI — More demo samples

Sign in at https://gem-bidsure-ai.vercel.app/. Create one tender per scenario.
Upload the tender PDF under **Document repository**. Click **Extract requirements**.
Approve only the certificate draft, then add the numeric requirement manually using
the exact fields below. The manual requirement configures the numeric threshold.

For each row in the bidder tables, add a separate bidder, select it from the
dropdown, upload the indicated PDF in **Bidder submissions**, and click
**Run verification**. Open the evidence excerpts, then export PDF or XLSX.

## Printer procurement

- Tender title: Office Printer Procurement
- GeM reference: DEMO-PRINT-002
- Tender PDF: printer-tender.pdf
- Approve: The bidder must submit a BIS registration certificate.
- Requirement description: Minimum print speed 30 ppm
- Metric: Print speed
- Minimum threshold: 30
- Unit: ppm

| Bidder name | Upload | Expected print-speed finding |
| --- | --- | --- |
| Exact Print Demo | printer-bidder-equal.pdf | COMPLIANT (30 ppm meets the minimum) |
| Conflicting Print Demo | printer-bidder-conflict.pdf | NEEDS MANUAL REVIEW (35 and 20 ppm) |

## Battery procurement

- Tender title: Portable Battery Procurement
- GeM reference: DEMO-BATT-003
- Tender PDF: battery-tender.pdf
- Approve: The bidder must submit an ISO certificate.
- Requirement description: Minimum battery capacity 5000 mAh
- Metric: Battery capacity
- Minimum threshold: 5000
- Unit: mAh

| Bidder name | Upload | Expected capacity finding |
| --- | --- | --- |
| High Capacity Demo | battery-bidder-pass.pdf | COMPLIANT (6000 mAh) |
| Missing Capacity Demo | battery-bidder-missing.pdf | MISSING (no matching capacity evidence) |

A MISSING finding means the app did not retrieve capacity evidence. The
certificate entries are evidence excerpts for a human to inspect.
